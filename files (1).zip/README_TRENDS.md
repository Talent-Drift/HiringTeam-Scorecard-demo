# Recruiter Scorecard - UPDATED with Historical Trends

## 🎉 NEW: Leadership Trends & Progress View

Your demo now includes **historical performance tracking** showing 3 months of improvement data across 6 biweekly snapshots. This is your killer sales feature - showing prospects that your platform drives real, measurable improvement.

---

## 📊 What's New

### **Trends & Progress (Leadership View)**

A dedicated dashboard showing:
- **Before/After comparison** (Started at 39.8, now at 64.2 = +24.4 points!)
- **Trend line charts** showing continuous improvement
- **Critical issues reduction** (46 → 19 violations)
- **Individual improvement tracking** (who improved most, who needs help)
- **Person-by-person trend lines** for every recruiter and hiring manager

**This answers the #1 leadership question: "Is this platform actually working?"**

---

## 📦 Complete File List for GitHub Upload

**You need ALL 6 files:**

1. **app.py** ← Main dashboard (NOW WITH TRENDS VIEW!)
2. **scoring_engine.py** ← Scoring calculations
3. **generate_sample_data.py** ← Creates current data
4. **sample_ats_export.csv** ← Current snapshot data
5. **requirements.txt** ← Python packages
6. **historical_performance_data.json** ← NEW! 3 months of trend data

---

## 🚀 Updated Setup Instructions

### Step 1: Download All 6 Files
Make sure you have:
- ✅ app.py
- ✅ scoring_engine.py
- ✅ generate_sample_data.py
- ✅ sample_ats_export.csv
- ✅ requirements.txt
- ✅ historical_performance_data.json ← **Don't forget this one!**

### Step 2: Upload to GitHub
1. Go to your GitHub repo
2. Click "Add file" → "Upload files"
3. Drag all 6 files
4. Click "Commit changes"

### Step 3: Deploy to Streamlit
1. Go to share.streamlit.io
2. Click "New app" (or "Reboot" if already deployed)
3. Select your repo
4. Main file: `app.py`
5. Click "Deploy!"

---

## 🎯 Updated Navigation

Your app now has **5 views**:

1. **Open Roles Dashboard** - Role-centric view showing recruiter+HM partnerships
2. **Trends & Progress (Leadership)** ← **NEW!** - Historical improvement tracking
3. **Organization Overview** - Team-wide metrics
4. **Recruiter Cards** - Individual recruiter deep dives
5. **Hiring Manager Cards** - Individual HM deep dives

---

## 💡 How to Demo the Trends View (The Killer Feature!)

### Opening (30 sec)
"One of the biggest concerns we hear from leaders is: 'How do I know this will actually work?' So we built in progress tracking. Let me show you what 3 months of using the platform looks like."

### Show the Summary Metrics (1 min)
**Click "Trends & Progress (Leadership)"**

Point to the top metrics:
- "You started at 39.8 out of 100 - that's rough. Your team had serious issues."
- "Three months later, you're at 64.2. That's a 24-point improvement."
- "More importantly, you went from 46 critical issues down to 19. That's real impact."

### Show the Trend Chart (1 min)
Point to the line chart:
- "See how this isn't random - it's steady, consistent improvement"
- "The green line is recruiters, orange is hiring managers. Both moving up together."
- "This proves your team is learning and adapting to the SLAs."

### Show Top Improvers (1 min)
Scroll to "Top 5 Most Improved":
- "Look at Tom Brady - went from 27 to 66. That's a 39-point jump."
- "He was your worst hiring manager. Now he's mid-tier. That's coaching in action."
- "You can literally see who's responding to the platform and who needs more support."

### Show Individual Trends (1 min)
Click the "Hiring Managers" tab:
- "Every single person has their own trend line"
- "You can pull up any hiring manager in a 1-on-1 and say: 'Here's your trajectory over the last 3 months. Let's talk about what's working.'"

### Close (30 sec)
"This is what makes our platform different. It's not just a report card - it's a coaching tool that proves ROI. You can literally show your CFO: 'We invested in this, and here's how our hiring velocity improved.'"

---

## 📈 Sample Data Highlights

Your demo shows:
- **Organization:** 39.8 → 64.2 (+24.4 points)
- **Recruiters:** 37.4 → 61.4 (+24.0 points)
- **Hiring Managers:** 41.3 → 66.0 (+24.7 points)
- **Critical Issues:** 46 → 19 (-27 violations)

**Top 3 Improvers:**
1. Tom Brady (HM): 27 → 66 (+39 points) ← "Worst to First" story
2. Mark Watson (HM): 36 → 70 (+34 points)
3. Robert Smith (HM): 28 → 62 (+34 points)

These are built into the data - memorize them for your demo!

---

## 🎤 Sales Talking Points

### For HR/Talent Leaders
"You can finally prove to leadership that your coaching is working. No more gut feel - here's the data."

### For CFOs/COOs
"This shows direct ROI. Faster hiring = less time-to-productivity = revenue impact. Here's the proof in numbers."

### For VPs/Department Heads
"Your hiring managers are bottlenecks. This shows you exactly who needs coaching and whether it's working."

### For Executives
"We reduced critical hiring delays by 58% in 3 months. That's millions in productivity gains."

---

## 🆘 Troubleshooting

### "Historical data not available" error
**Fix:** Make sure `historical_performance_data.json` is uploaded to GitHub
1. Go to your repo
2. Check file list - should see 6 files
3. If missing, upload it
4. Reboot the Streamlit app

### Trends page is blank
**Fix:** The JSON file might not have loaded
1. In Streamlit Cloud, click "Manage app" → "Logs"
2. Look for errors mentioning "historical_performance_data.json"
3. Make sure the file is in the root directory (not in a subfolder)

### Want to regenerate the historical data?
Run this locally (not needed for the demo, but if you want fresh data):
```bash
python generate_historical_data.py
```
This creates a new `historical_performance_data.json` file.

---

## 🎯 Updated Demo Flow (7 Minutes Total)

**Minute 1-2:** Open Roles Dashboard (show role-level scores)
**Minute 3-5:** Trends & Progress ← **This is your wow moment**
**Minute 6:** Recruiter Cards (drill into an individual)
**Minute 7:** Q&A

Focus 60% of your demo time on the Trends view - that's what closes deals.

---

## 💪 Why This Feature Sells

1. **Proves ROI** - Numbers going up = success
2. **Addresses skepticism** - "Will this actually work?" → "Here's proof it works"
3. **Individual coaching tool** - Shows who to invest in
4. **Executive-friendly** - Simple, visual, compelling

Prospects see: "If I buy this, in 3 months I can show my board a 24-point improvement."

---

## 📊 Technical Notes

### How Historical Data Works
- **6 snapshots** = 5 past periods + 1 current
- **Biweekly cadence** = matches typical talent review cycles
- **Improvement algorithm** = Each person has a baseline + growth rate
- **Realistic variation** = Some people improve faster than others

### Data Generation
The `generate_historical_data.py` script:
- Creates consistent improvement trajectories
- Models real coaching impact (some people respond better)
- Includes "turnaround stories" (Tom Brady: 27→66)
- Ensures org-level trends are positive

---

## 🚀 You're Ready When

✅ All 6 files uploaded to GitHub
✅ Streamlit app shows "Trends & Progress" in navigation
✅ Clicking it shows charts with 6 data points
✅ You've practiced the 5-minute trends walkthrough
✅ You can explain Tom Brady's 39-point improvement

---

**Questions?** You now have the most powerful demo feature: proof that your product drives real improvement. Use it!

---

## Next Steps

1. **Upload all 6 files to GitHub** (especially the JSON!)
2. **Deploy/Reboot on Streamlit Cloud**
3. **Click "Trends & Progress" to test it**
4. **Practice the demo script above**
5. **Book your first demo!**

Good luck! 🎉
